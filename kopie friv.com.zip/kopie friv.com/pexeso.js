let list = [
    "Pepa",
    "Pepa",
    "Honza",
    "Honza",
    "Lukáš",
    "Lukáš",
    "Alex",
    "Alex",
    "Matyáš",
    "Matyáš",
    "Petr",
    "Petr",
];

let match = "";
let click = 0;
let count = 0;

function check() {
    if (count === 6) {
        window.alert("Vyhrál jsi!");
        resetGame();
    }
}

function resetGame() {
    click = 0;
    count = 0;
    match = "";

    document.querySelectorAll(".card-item").forEach((card) => {
        card.style.display = "none";
        card.classList.remove("active");
    });

    list = shuffleList(list);

    document.getElementById("count").innerText = `Počet tahů: ${click}`;

    list.forEach(createCard);
}

function shuffleList(List) {
    for (let i = List.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        [List[i], List[j]] = [List[j], List[i]];
    }
    return List;
}

let toggle = (text) => {
    click++;
    document.getElementById("count").innerText = `Počet tahů: ${click}`;

    text.classList.toggle("active");

    if (text.style.display === "block") {
        text.style.display = "none";
        match = "";
    } else {
        text.style.display = "block";

        if (match === "") {
            match = text;
        } else if (match.innerText === text.innerText) {
            [text.style.display, match.style.display] = ["inline", "inline"];
            count++;
            match = "";
            setTimeout(check, 500);
        } else {
            setTimeout(() => {
                [text.style.display, match.style.display, match] = ["none", "none", ""];
            }, 500);
        }
    }
};

function createCard(e) {
    const cardItem = document.createElement("div");
    cardItem.classList.add("card-item");

    const text = document.createElement("p");
    text.innerText = e;
    text.style.display = "none";

    cardItem.appendChild(text);
    cardItem.addEventListener("click", () => toggle(text));

    const container = document.getElementById("card");
    const randomIndex = Math.floor(Math.random() * container.children.length);
    container.insertBefore(cardItem, container.children[randomIndex]);
}

list = shuffleList(list);
list.forEach(createCard);

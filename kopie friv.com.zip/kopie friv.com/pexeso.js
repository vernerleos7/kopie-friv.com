let list = [
    { image: "images/acai.png" },
    { image: "images/acai.png" },
    { image: "images/banana.png" },
    { image: "images/banana.png" },
    { image: "images/pineapple.png" },
    { image: "images/pineapple.png" },
    { image: "images/star-apple.png" },
    { image: "images/star-apple.png" },
    { image: "images/watermelon.png" },
    { image: "images/watermelon.png" },
    { image: "images/orange.png" },
    { image: "images/orange.png" },
];

let match = "";
let click = 0;
let count = 0;

function check() {
    if (count === 6) {
        window.alert("Vyhrál jsi!");
        resetGame();
    }
}

function resetGame() {
    click = 0;
    count = 0;
    match = "";

    document.querySelectorAll(".card-item").forEach((card) => {
        card.style.display = "none";
        card.classList.remove("active");
    });

    list = shuffleList(list);

    document.getElementById("count").innerText = `Počet tahů: ${click}`;

    list.forEach(createCard);
}

function shuffleList(List) {
    for (let i = List.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        [List[i], List[j]] = [List[j], List[i]];
    }
    return List;
}

let toggle = (cardItem) => {
    click++;
    document.getElementById("count").innerText = `Počet tahů: ${click}`;

    cardItem.classList.toggle("active");

    const image = cardItem.querySelector("img");

    if (image.style.display === "block") {
        image.style.display = "none";
        match = "";
    } else {
        image.style.display = "block";

        if (match === "") {
            match = image;
        } else if (match.src === image.src) {
            [image.style.display, match.style.display] = ["inline", "inline"];
            count++;
            match = "";
            setTimeout(check, 500);
        } else {
            setTimeout(() => {
                [image.style.display, match.style.display, match] = ["none", "none", ""];
            }, 500);
        }
    }
};

function createCard(e) {
    const cardItem = document.createElement("div");
    cardItem.classList.add("card-item");

    const image = document.createElement("img");
    image.src = e.image;
    image.style.width = "100%";
    image.style.height = "100%";
    image.style.objectFit = "fit";
    image.style.display = "none";

    cardItem.appendChild(image);
    cardItem.addEventListener("click", () => toggle(cardItem));

    const container = document.getElementById("card");
    const randomIndex = Math.floor(Math.random() * container.children.length);
    container.insertBefore(cardItem, container.children[randomIndex]);
}

list = shuffleList(list);
list.forEach(createCard);

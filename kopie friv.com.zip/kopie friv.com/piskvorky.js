let currentPlayer = 'X';
let board = ['', '', '', '', '', '', '', '', ''];
let gameActive = true;

function renderBoard() {
    const boardElement = document.getElementById('board');
    boardElement.innerHTML = '';

    for (let i = 0; i < 3; i++) {
        const row = document.createElement('tr');
        for (let j = 0; j < 3; j++) {
            const cell = document.createElement('td');
            cell.classList.add('cell');
            cell.textContent = board[i * 3 + j];
            cell.addEventListener('click', () => handleCellClick(i * 3 + j));
            row.appendChild(cell);
        }
        boardElement.appendChild(row);
    }
}

function handleCellClick(index) {
    if (!gameActive || board[index] !== '') {
        return;
    }

    board[index] = currentPlayer;
    renderBoard();
    checkWinner();

    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
}

function checkWinner() {
    const winningCombinations = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
    ];

    for (const combo of winningCombinations) {
        const [a, b, c] = combo;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            alert(`${currentPlayer} vyhrál!`);
            resetGame();
            return;
        }
    }

    if (!board.includes('')) {
        alert('Je to nerozhodně!');
        resetGame();
    }
}

function resetGame() {
    gameActive = true;
    board = ['', '', '', '', '', '', '', '', ''];
    renderBoard();
}

// Inicializace hry
renderBoard();

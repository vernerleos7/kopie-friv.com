const bird = document.getElementById('bird');
const pipe1 = document.getElementById('pipe1');
const pipe2 = document.getElementById('pipe2');
let isJumping = false;
let birdTop = 1;
let birdSpeed = 0;
let birdDirection = 1;

document.addEventListener('keydown', (event) => {
    if (event.code === 'Space' && !isJumping) {
        isJumping = true;
        birdSpeed = 30;
    }
});

function updateBirdPosition() {
    if (isJumping) {
        birdTop -= birdSpeed;
        birdSpeed -= 2;
        birdTop = Math.max(0, Math.min(50, birdTop));
        bird.style.top = `${birdTop}%`;
        if (birdTop === 50) isJumping = false;
    } else {
        birdTop = Math.min(100, birdTop + 1);
        bird.style.top = `${birdTop}%`;
    }

    bird.style.left = `${parseFloat(bird.style.left) + 0.8 * birdDirection}%`;
    if (parseFloat(bird.style.left) > 100) bird.style.left = '-50%';
}

function movePipe(pipe, initialPosition) {
    let pipePosition = initialPosition;

    setInterval(() => {
        pipe.style.left = `${pipePosition}%`;
        if (pipePosition <= -50) pipePosition = initialPosition;
        pipePosition -= 1;
    }, 20);
}

setInterval(updateBirdPosition, 20);
movePipe(pipe1, 150);
movePipe(pipe2, 200);
